/**
* Copyright 2018 aheadWorks. All rights reserved. 
*  See LICENSE.txt for license details.
*/

var config = {
    map: {
        '*': {
            awSbbProductListLayout:  'Aheadworks_ShopByBrand/js/product-list/layout'
        }
    },
    paths: {
        'slick': 'Aheadworks_ShopByBrand/js/slick'
    }
};
