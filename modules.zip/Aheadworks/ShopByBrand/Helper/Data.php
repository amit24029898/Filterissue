<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of State
 *
 * @author haihao.yan
 */
namespace Aheadworks\ShopByBrand\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper{

	protected $connection = null;
	protected $storeManager = null;
	protected $objectManager = null;
	
	public function __construct()
	{
		$this->objectManager = \Magento\Framework\App\ObjectManager::getInstance(); // Instance of object manager
		$this->getConnection();
		$this->storeManager = $this->objectManager->get('Magento\Store\Model\StoreManagerInterface');
	}
	
	public function getConnection()
	{		
		$resource = $this->objectManager->get('Magento\Framework\App\ResourceConnection');
		$this->connection = $resource->getConnection();
	}
    public function getStoreLinkByProductId($product)
	{		
		$html = '';
		//$storeId = $this->checkProductInStore($product->getId());		
		if($product->getHasInStore()) {						
			$html .= '<div class="no-price"><h4>Sorry.</h4><p>'.__("Prices are only available in-store").'</p><div class="btns"><a href="'.$this->storeManager->getStore()->getUrl('storelocator').'"><span>'.__("Click here for the store locator").'</span></a></div></div>';			
		}
		return $html;
	}
	
	public function canShowPrice($product)
	{
		//$storeId = $this->checkProductInStore($product->getId());
		if($product->getHasInStore()) {
			return 0;
		}
		return 1;
		/*$select = "select option_id from aw_sbb_brand where is_in_store='".'1'."'";
		 $prodCollection = $$this->objectManager->create('Magento\Catalog\Model\ResourceModel\Product\CollectionFactory');
    	$collection = $prodCollection->create()
        ->addAttributeToSelect('*')
        ->addAttributeToFilter('manufacturer',$select)
        ->load();*/
		

	}
	
	public function checkProductInStore($productId=0)
	{		
		$select = "select stores_id from ecomteck_storelocator_products where product_id = '".$productId."' limit 1";
		$rs = $this->connection->fetchRow($select);
		if(isset($rs['stores_id'])) {
			return $rs['stores_id'];
		}
		return 0;
	}
	
	public function getAvailableStoreMessage($product)
	{//$product->getData('manufacturer')
		//$storeId = $this->checkProductInStore($product->getId());
		if($product->getHasInStore()) {
			return "<div class='price-availability-text'>".__("Prices available in-store")."</div>";
		}
	}
}

?>
